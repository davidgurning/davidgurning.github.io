<!DOCTYPE html>
<html lang="en">
    <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Portofolio-Website</title>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="https://unpkg.com/feather-icons"></script>

    
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    

    
    <link rel="stylesheet" href="style/style.css" />
    <link rel="stylesheet" href="style/styleprog.css">
    <link rel="stylesheet" href="style/timeline.css">
    <link rel="stylesheet" href="responsive/responsive.css">
    
    <link rel="stylesheet" href="contact/contact.css">
    <link rel="stylesheet" href="style/slideshow.css">
    
  </head>
<body>
    <div class="modal-content">
        
        <div class="modal-header">
          <h4 class="modal-title text-dark" >Tambah Sertifikat</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
  
        
        <div class="modal-body">
          <form id="myForm" action="/serti/<?php echo e($serti->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php echo method_field('PUT'); ?>
            <div class="form-group">
              <label for="jenissertifikat" class="text-dark">jenis Sertifikat</label>
            <select type="text" class="form-control" id="jenissertifikat" name="jenissertifikat">
              <option value="senior high school" class="text-dark" <?php echo e($serti-> jenissertifikat == 'senior high school' ? 'selected' : ''); ?>>Senior High School</option>
              <option value="code competition" class="text-dark" <?php echo e($serti-> jenissertifikat == 'code competition' ? 'selected' : ''); ?>>Code Competition</option>
              <option value="course" class="text-dark" <?php echo e($serti-> jenissertifikat == 'course' ? 'selected' : ''); ?>>Course</option>
              <option value="organization" class="text-dark" <?php echo e($serti-> jenissertifikat == 'organizatio' ? 'selected' : ''); ?>>Organization</option>
            </select>
  
              <label for="gambarsertifikat" class="text-dark">Gambar Sertifikat</label>
              <input type="file" class="form-control" id="gambarsertifikat" name="gambarsertifikat" value="<?php echo e($serti->gambarsertifikat); ?>">>
              <?php $__errorArgs = ['gambarsertifikat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  
              <label for="judulsertifikat" class="text-dark">Judul Sertifikat</label>
              <input type="text" class="form-control" id="judulsertifikat" name="judulsertifikat" value="<?php echo e($serti->judulsertifikat); ?>">
              <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="alert alert-danger"><?php echo e($message); ?></div>
              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
        </div>
      </div>
</body>
</html><?php /**PATH C:\PERSONAL\MANDIRI\PersonalWebsite\websitePribadi\resources\views/serti/edit.blade.php ENDPATH**/ ?>