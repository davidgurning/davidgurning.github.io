<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Portofolio-Website</title>
        <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    
        <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
        <script src="https://unpkg.com/feather-icons"></script>
    
        
        <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
        
    
        
        <link rel="stylesheet" href="style/style.css" />
        <link rel="stylesheet" href="style/styleprog.css">
        <link rel="stylesheet" href="style/timeline.css">
        <link rel="stylesheet" href="responsive/responsive.css">
        
        <link rel="stylesheet" href="contact/contact.css">
        <link rel="stylesheet" href="style/slideshow.css">
        
      </head>
<body>
    <form id="myForm" action="/portofolio/<?php echo e($portofolio->id); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('PUT'); ?>
       
        <div class="form-group">
          <label for="judul" class="text-dark">judul</label>
          <input type="text" class="form-control" id="judul" name="judul" value="<?php echo e($portofolio->judul); ?>">
          <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"<?php echo e($message); ?>></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <label for="gambar" class="text-dark">Gambar</label>
          <input type="file" class="form-control" id="gambar" name="gambar" value="<?php echo e($portofolio->gambar); ?>">
          <?php $__errorArgs = ['gambar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <label for="pesan" class="text-dark">Pesan</label>
          <input type="text" class="form-control" id="pesan" name="pesan" value="<?php echo e($portofolio->pesan); ?>">
          <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

          <label for="jenisprestasi" class="text-dark">Jenis Prestasi</label>
          <select class="form-control" id="jenisprestasi" name="jenisprestasi">
              <option value="website" class="text-dark" <?php echo e($portofolio->jenisprestasi == 'website' ? 'selected' : ''); ?>>Website</option>
              <option value="design" class="text-dark" <?php echo e($portofolio->jenisprestasi == 'design' ? 'selected' : ''); ?>>Design</option>
              <option value="mobile" class="text-dark" <?php echo e($portofolio->jenisprestasi == 'mobile' ? 'selected' : ''); ?>>Mobile</option>
          </select>
          

          <?php $__errorArgs = ['pesan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>
        <button type="submit" class="btn btn-primary inisubmitya">Submit</button>
      </form>
</body>
</html><?php /**PATH C:\PERSONAL\MANDIRI\PersonalWebsite\websitePribadi\resources\views/portofolio/edit.blade.php ENDPATH**/ ?>